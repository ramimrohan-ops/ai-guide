"use strict";

// The list the app downloads each time it opens. Edit data.json in this repo to update every phone.
const DATA_URL = "https://raw.githubusercontent.com/ramimrohan-ops/ai-guide/main/data.json";
const STORE_KEY = "whichai-data-v1";
const SUPPORTED_VERSION = 1;

const app = document.getElementById("app");

const state = {
  data: null,
  online: null, // null = not checked yet, true = latest list downloaded, false = could not reach it
  refreshing: false,
  error: "",
  query: "",
};

let depth = (history.state && history.state.depth) || 0;
const scrollMemory = {};

/* ---------- helpers ---------- */

function el(tag, attrs, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === false || value == null) continue;
    if (key === "class") node.className = value;
    else if (key === "style") node.setAttribute("style", value);
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? "" : value);
  }
  for (const child of children.flat()) {
    if (child == null || child === false) continue;
    node.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return node;
}

function svgIcon(path) {
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("fill", "none");
  svg.setAttribute("stroke", "currentColor");
  svg.setAttribute("stroke-width", "2");
  svg.setAttribute("stroke-linecap", "round");
  svg.setAttribute("stroke-linejoin", "round");
  svg.setAttribute("aria-hidden", "true");
  const p = document.createElementNS(ns, "path");
  p.setAttribute("d", path);
  svg.append(p);
  return svg;
}

const ICON_REFRESH = "M21 12a9 9 0 1 1-2.64-6.36M21 4v5h-5";
const ICON_BACK = "M15 5l-7 7 7 7";

function formatDate(iso) {
  const d = new Date(iso + "T00:00:00");
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

function safeUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === "https:" || u.protocol === "http:" ? u.href : null;
  } catch {
    return null;
  }
}

/* ---------- data ---------- */

// Only accept a list we fully understand; anything else is ignored so a bad edit can't break the app.
function validate(raw) {
  if (!raw || typeof raw !== "object") return null;
  if (typeof raw.version !== "number" || raw.version > SUPPORTED_VERSION) return null;
  if (typeof raw.updated !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(raw.updated)) return null;
  if (!Array.isArray(raw.jobs) || !raw.tools || typeof raw.tools !== "object") return null;

  const tools = {};
  for (const [id, t] of Object.entries(raw.tools)) {
    if (!t || typeof t.name !== "string") continue;
    tools[id] = {
      name: t.name,
      maker: typeof t.maker === "string" ? t.maker : "",
      url: safeUrl(t.url),
      price: typeof t.price === "string" ? t.price : "",
      blurb: typeof t.blurb === "string" ? t.blurb : "",
    };
  }

  const jobs = [];
  for (const j of raw.jobs) {
    if (!j || typeof j.id !== "string" || typeof j.name !== "string" || !Array.isArray(j.picks)) continue;
    const picks = j.picks
      .filter((p) => p && tools[p.tool])
      .map((p) => ({
        tool: p.tool,
        why: typeof p.why === "string" ? p.why : "",
        evidence: typeof p.evidence === "string" ? p.evidence : "",
        skip: typeof p.skip === "string" ? p.skip : "",
      }));
    if (!picks.length) continue;
    const hue = Number.isFinite(j.hue) ? ((j.hue % 360) + 360) % 360 : 215;
    const sources = (Array.isArray(j.sources) ? j.sources : [])
      .filter((s) => s && typeof s.name === "string" && safeUrl(s.url))
      .map((s) => ({ name: s.name, url: safeUrl(s.url) }));
    jobs.push({ id: j.id, name: j.name, hint: typeof j.hint === "string" ? j.hint : "", hue, picks, sources });
  }
  if (!jobs.length) return null;

  return { version: raw.version, updated: raw.updated, note: typeof raw.note === "string" ? raw.note : "", jobs, tools };
}

function readSaved() {
  try {
    return validate(JSON.parse(localStorage.getItem(STORE_KEY)));
  } catch {
    return null;
  }
}

function save(data) {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(data));
  } catch {
    /* storage can be unavailable; the list still works for this session */
  }
}

async function loadBundled() {
  const res = await fetch("data.json");
  return validate(await res.json());
}

async function refresh() {
  if (state.refreshing) return;
  state.refreshing = true;
  state.error = "";
  render();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(DATA_URL, { cache: "no-store", signal: controller.signal });
    if (!res.ok) throw new Error("http " + res.status);
    const fresh = validate(await res.json());
    if (!fresh) {
      state.online = true;
      state.error = "The online list could not be read, so the saved one is still in use.";
    } else {
      state.online = true;
      if (fresh.updated >= state.data.updated) {
        state.data = fresh;
        save(fresh);
      }
    }
  } catch {
    state.online = false;
  } finally {
    clearTimeout(timer);
    state.refreshing = false;
    render();
  }
}

/* ---------- views ---------- */

function statusBar() {
  let text = "Checking for a newer list";
  let cls = "dot";
  if (!state.refreshing && state.online === true) {
    text = "Up to date, list from " + formatDate(state.data.updated);
    cls = "dot online";
  } else if (!state.refreshing && state.online === false) {
    text = "Offline, showing list from " + formatDate(state.data.updated);
    cls = "dot offline";
  } else if (state.online == null && !state.refreshing) {
    text = "List from " + formatDate(state.data.updated);
  }
  return el(
    "div",
    { class: "status" },
    el("div", { class: "status-text" }, el("span", { class: cls }), el("span", {}, text)),
    el(
      "button",
      { class: "icon-btn" + (state.refreshing ? " spin" : ""), "aria-label": "Check for a newer list", onclick: refresh },
      svgIcon(ICON_REFRESH)
    )
  );
}

function jobRow(job) {
  const top = state.data.tools[job.picks[0].tool];
  return el(
    "li",
    {},
    el(
      "button",
      { class: "row hue", style: `--h:${job.hue}`, onclick: () => go("#/job/" + job.id) },
      el("span", { class: "bar" }),
      el("span", {}, el("div", { class: "row-name" }, job.name), el("div", { class: "row-hint" }, job.hint)),
      el("span", { class: "row-pick" }, top.name)
    )
  );
}

function toolRow(id) {
  const t = state.data.tools[id];
  const jobs = state.data.jobs.filter((j) => j.picks.some((p) => p.tool === id));
  const first = jobs[0];
  return el(
    "li",
    {},
    el(
      "button",
      { class: "row hue", style: `--h:${first ? first.hue : 215}`, onclick: () => go("#/tool/" + id) },
      el("span", { class: "bar" }),
      el(
        "span",
        {},
        el("div", { class: "row-name" }, t.name),
        el("div", { class: "row-hint" }, jobs.length ? "Good for " + jobs.map((j) => j.name.toLowerCase()).join(", ") : t.blurb)
      ),
      el("span", {})
    )
  );
}

function homeView() {
  const q = state.query.trim().toLowerCase();
  const { jobs, tools } = state.data;

  const input = el("input", {
    type: "search",
    placeholder: "Search a job or an AI",
    "aria-label": "Search a job or an AI",
    value: state.query,
    autocomplete: "off",
    spellcheck: "false",
  });
  input.addEventListener("input", () => {
    state.query = input.value;
    const pos = input.selectionStart;
    render();
    const next = document.querySelector(".search input");
    if (next) {
      next.focus();
      try { next.setSelectionRange(pos, pos); } catch { /* ignore */ }
    }
  });

  let body;
  if (!q) {
    body = el("ul", { class: "list" }, jobs.map(jobRow));
  } else {
    const jobHits = jobs.filter(
      (j) => (j.name + " " + j.hint).toLowerCase().includes(q)
    );
    const toolHits = Object.keys(tools).filter((id) => tools[id].name.toLowerCase().includes(q));
    if (!jobHits.length && !toolHits.length) {
      body = el("p", { class: "empty" }, "Nothing matches “" + state.query.trim() + "”. Try a job such as coding or video, or an AI's name.");
    } else {
      body = el(
        "div",
        {},
        jobHits.length ? [el("p", { class: "group-title" }, "Jobs"), el("ul", { class: "list" }, jobHits.map(jobRow))] : null,
        toolHits.length ? [el("p", { class: "group-title" }, "AI tools"), el("ul", { class: "list" }, toolHits.map(toolRow))] : null
      );
    }
  }

  return el(
    "main",
    { class: "screen" },
    el("header", { class: "top" }, el("h1", {}, "Which AI for the job?"), statusBar()),
    state.error ? el("p", { class: "err" }, state.error) : null,
    el("div", { class: "search" }, input),
    body,
    q ? null : el("p", { class: "note" }, state.data.note)
  );
}

function backBar() {
  return el(
    "div",
    { class: "bar-top" },
    el("button", { class: "icon-btn", "aria-label": "Back", onclick: goBack }, svgIcon(ICON_BACK))
  );
}

function openButton(tool, label) {
  if (!tool.url) return null;
  return el("a", { class: "btn", href: tool.url, target: "_blank", rel: "noopener noreferrer" }, label || "Open " + tool.name);
}

function jobView(id) {
  const job = state.data.jobs.find((j) => j.id === id);
  if (!job) return notFound();
  const [best, ...rest] = job.picks;
  const t = state.data.tools[best.tool];
  return el(
    "main",
    { class: "screen hue", style: `--h:${job.hue}` },
    backBar(),
    el("h2", {}, job.name),
    el("p", { class: "lede" }, job.hint),
    el(
      "section",
      { class: "best" },
      el("p", { class: "tag" }, "Best pick"),
      el("h3", {}, t.name),
      el("p", {}, best.why),
      evidenceLine(best),
      best.skip ? el("p", { class: "skip" }, el("b", {}, "Skip it if: "), best.skip) : null,
      el("p", { class: "skip" }, t.price),
      openButton(t)
    ),
    rest.length
      ? el(
          "section",
          { class: "also" },
          el("p", { class: "also-title" }, "Also good"),
          rest.map((p) => {
            const tool = state.data.tools[p.tool];
            return el(
              "button",
              { class: "pick", onclick: () => go("#/tool/" + p.tool) },
              el("div", { class: "pick-head" }, el("span", { class: "pick-name" }, tool.name), el("span", { class: "pick-price" }, tool.price)),
              el("p", {}, p.why),
              evidenceLine(p),
              p.skip ? el("p", { class: "skip" }, el("b", {}, "Skip it if: "), p.skip) : null
            );
          })
        )
      : null,
    job.sources.length
      ? el(
          "section",
          { class: "sources" },
          el("p", { class: "also-title" }, "Based on"),
          el(
            "ul",
            {},
            job.sources.map((s) =>
              el("li", {}, el("a", { href: s.url, target: "_blank", rel: "noopener noreferrer" }, s.name))
            )
          )
        )
      : null
  );
}

function evidenceLine(pick) {
  if (!pick.evidence) return null;
  return el("p", { class: "evidence" }, el("b", {}, "Evidence: "), pick.evidence);
}

function toolView(id) {
  const tool = state.data.tools[id];
  if (!tool) return notFound();
  const jobs = state.data.jobs.filter((j) => j.picks.some((p) => p.tool === id));
  const hue = jobs[0] ? jobs[0].hue : 215;
  return el(
    "main",
    { class: "screen hue", style: `--h:${hue}` },
    backBar(),
    el("h2", {}, tool.name),
    el("p", { class: "lede" }, tool.maker ? "By " + tool.maker : ""),
    el("p", { class: "about" }, tool.blurb),
    el("ul", { class: "facts" }, tool.price ? el("li", {}, el("b", {}, "Price: "), tool.price) : null),
    jobs.length ? el("p", { class: "group-title" }, "Where it fits") : null,
    el(
      "ul",
      { class: "list" },
      jobs.map((j) => {
        const rank = j.picks.findIndex((p) => p.tool === id);
        const pick = j.picks[rank];
        return el(
          "li",
          {},
          el(
            "button",
            { class: "row hue", style: `--h:${j.hue}`, onclick: () => go("#/job/" + j.id) },
            el("span", { class: "bar" }),
            el("span", {}, el("div", { class: "row-name" }, j.name), el("div", { class: "row-hint" }, pick.why)),
            el("span", { class: "row-pick" }, rank === 0 ? "Best pick" : "Also good")
          )
        );
      })
    ),
    openButton(tool)
  );
}

function notFound() {
  return el("main", { class: "screen" }, backBar(), el("h2", {}, "Not found"), el("p", { class: "lede" }, "That page is no longer in the list."));
}

/* ---------- routing ---------- */

function currentRoute() {
  return location.hash || "#/";
}

// pushState keeps Android's back button working: each screen is a real history entry.
function go(hash) {
  scrollMemory[currentRoute()] = window.scrollY;
  depth += 1;
  history.pushState({ depth }, "", hash);
  render();
  window.scrollTo(0, 0);
}

function goBack() {
  if (depth > 0) {
    history.back();
  } else {
    history.replaceState({ depth: 0 }, "", "#/");
    render();
    window.scrollTo(0, scrollMemory["#/"] || 0);
  }
}

function render() {
  if (!state.data) return;
  const route = location.hash || "#/";
  let view;
  if (route.startsWith("#/job/")) view = jobView(decodeURIComponent(route.slice(6)));
  else if (route.startsWith("#/tool/")) view = toolView(decodeURIComponent(route.slice(7)));
  else view = homeView();
  app.replaceChildren(view);
  shownRoute = route;
}

let shownRoute = currentRoute();
window.addEventListener("popstate", (event) => {
  scrollMemory[shownRoute] = window.scrollY;
  depth = (event.state && event.state.depth) || 0;
  render();
  window.scrollTo(0, scrollMemory[currentRoute()] || 0);
});

/* ---------- start ---------- */

(async function init() {
  let bundled = null;
  try {
    bundled = await loadBundled();
  } catch {
    /* handled below */
  }
  const saved = readSaved();
  state.data = saved && bundled ? (saved.updated >= bundled.updated ? saved : bundled) : saved || bundled;
  if (!state.data) {
    app.textContent = "The list could not be loaded. Reinstall the app.";
    return;
  }
  render();
  refresh();
})();
